package sample;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class Menu extends VBox {

    public Menu() {
        // Création des boutons du menu
        Button startButton = new Button("Start");
        Button exitButton = new Button("Exit");

        // Ajout des écouteurs d'événements aux boutons
        startButton.setOnAction(event -> {
            System.out.println("Start button clicked");
            // Mettez ici le code pour démarrer le jeu
        });
        exitButton.setOnAction(event -> {
            System.out.println("Exit button clicked");
            // Mettez ici le code pour quitter l'application
        });

        // Configuration du layout du menu
        setSpacing(10);
        setAlignment(Pos.CENTER);
        setPadding(new Insets(20));
        
        // Ajout des boutons au menu
        getChildren().addAll(startButton, exitButton);
    }
}
